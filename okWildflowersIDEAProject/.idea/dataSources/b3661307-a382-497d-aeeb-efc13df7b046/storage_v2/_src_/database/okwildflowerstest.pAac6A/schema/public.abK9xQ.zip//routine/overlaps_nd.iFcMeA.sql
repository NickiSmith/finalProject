create function overlaps_nd(geometry, gidx) returns boolean
    immutable
    strict
    language sql
as
$$
SELECT $2 OPERATOR(public.&&&) $1;
$$;

alter function overlaps_nd(geometry, gidx) owner to postgres;


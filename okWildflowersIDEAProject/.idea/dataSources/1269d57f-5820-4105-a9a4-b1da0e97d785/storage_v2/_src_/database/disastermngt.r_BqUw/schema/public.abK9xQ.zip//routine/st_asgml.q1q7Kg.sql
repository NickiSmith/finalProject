create function st_asgml(geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_AsGML(2, $1, $2, $3, null, null);
$$;

alter function st_asgml(geometry, integer, integer) owner to postgres;

